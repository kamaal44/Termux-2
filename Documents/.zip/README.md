![Termux Logo](Termux.png)

---

#### Termux is an Android terminal emulator and Linux environment app that works directly with no rooting or setup required. A minimal base system is installed automatically - additional packages are available using the APT package manager.

# All the Termux files I use on my Devices

# 🖥     📱     💻

---

## Fresh Install

# 📱

```bash
bash <(curl -fsSL https://raw.githubusercontent.com/NateWeiler/Termux/master/installs/Fresh-Install.sh)
```

# 💻


---
