TEST_KEY = "TestKey"
TEST_VALUE = "TextValue"
BUILD_DIR = "Built_App"
BUNDLE_NAME = "Bundle"
