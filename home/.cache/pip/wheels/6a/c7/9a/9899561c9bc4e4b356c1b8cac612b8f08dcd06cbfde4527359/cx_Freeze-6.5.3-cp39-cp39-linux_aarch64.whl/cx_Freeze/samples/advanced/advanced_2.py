#!/usr/bin/env python

print("Hello from cx_Freeze Advanced #2\n")

module = __import__("testfreeze_2")
